const {app} = require('electron')
const _path = require('path')
const {spawn, execSync} = require('child_process')
const options = require('./options')
const Aria2 = require('aria2')

const DEVELOPING = true
const ARIA_FILENAME = 'usertaskd'
let ariaPath = _path.join(app.getAppPath(), 'app.asar.unpacked', ARIA_FILENAME)
if (DEVELOPING) {
  ariaPath = `/Users/shixiao/Playground/downloads/${ARIA_FILENAME}`
}
const DEFAULT_PORT = 6800
console.log(ariaPath)

class Provider {

  constructor (path, options) {
    this.options = options
    this.path = path
    this._onStart = []
    this.handler = null
    this.ready = false
    this.terminating = false
    this.port = DEFAULT_PORT
    this.a = null

    app.on('quit', () => {
      if (this.a) {
        this.a.saveSession()
        this.a.shutdown()
      }
    })
    this.onStart(() => {
      console.log('ON START! 1')
      this.a = new Aria2({'host': 'localhost', 'port': this.port})
      this.a.onopen = function () {
        console.log('aria2 open')
      }
      this.a.onclose = function () {
        console.log('aria2 closed!')
      }
    })
  }

  async init () {
    try {
      execSync(`killall -9 ${ARIA_FILENAME}`)
      console.log('KILLED!')
    } catch (e) {
    }
    console.log('INIT!')
    this.start()
    console.log('INITED!')
  }

  start () {
    console.log('Start!', this.path, options)
    const opts = options.concat([`--rpc-listen-port=${this.port}`])
    console.log('Start! 2', opts)
    this.handler = spawn(this.path)
    console.log('ON START! 0')

    this._onStart.forEach(cb => cb(this.port))
    console.log('ON START! 2')

    this.handler.stdout.on('data', (data) => {
      console.log(`stdout: ${data}`)
    })
    this.handler.stderr.on('data', (data) => {
      console.log(`stderr: ${data}`)
    })
    this.handler.on('close', (code) => {
      console.log(`child process exited with code ${code}`)
      if (!this.terminating) {
        console.log('restart...')
        this.port++
        this.start()
      }
    })
  }

  kill () {
    if (this.handler && this.handler.kill) {
      this.terminating = true
      return this.handler.kill()
    }
  }

  onStart (cb) {
    this._onStart.push(cb)
  }
}

const ap = new Provider(ariaPath, options)
module.exports = {
  get: () => ap,
}
