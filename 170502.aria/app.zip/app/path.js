const TARGET = 'main'// COLLECT: MODIFY ENTRIES

const main = require('url').format({
  protocol: 'file',
  slashes:  true,
  pathname: require('path').
              resolve(__dirname, '..', 'interface', 'main', 'index.html'),
})
const _new = require('url').format({
  protocol: 'file',
  slashes:  true,
  pathname: require('path').
              resolve(__dirname, '..', 'interface', 'new', 'index.html'),
})
const live = 'http://localhost:4200'

const [
  MAIN_PATH,
  NEW_PATH,
] = (function (target) {
  switch (target) {
    case 'main':
      return [live, _new]
    case 'new':
      return [main, live]
    case 'build':
      return [main, _new]
  }
})(TARGET)

module.exports = {
  MAIN_PATH,
  NEW_PATH,
}