const {BrowserWindow, Menu} = require('electron')
const PATH = require('./path').MAIN_PATH
const option = {
  width:          900,
  height:         640,
  minWidth:       480,
  minHeight:      480,
  maxWidth:       1200,
  maxHeight:      5000,
  resizable:      true,
  fullscreenable: false,
  maximizable:    false,
  alwaysOnTop:    true,
  show:           false,
  // title:          '',
  webPreferences: {
    webSecurity: false,
  },
}

class MainWindow {

  constructor (isBeforeQuitFn) {
    this.isBeforeQuitFn = isBeforeQuitFn
  }

  create () {
    let w = new BrowserWindow(option)
    w.loadURL(PATH)
    w.webContents.openDevTools();
    w.on('ready-to-show', () => w.show())
    w.on('closed', () => this.destroy())
    w.on('close', (e) => {
      if (!this.isBeforeQuitFn()) {
        this.w.hide()
        e.preventDefault()
      }
    })
    this.w = w
  }

  destroy () {
    this.w = null
  }
}

module.exports = function () {
  return new MainWindow(...arguments)
}