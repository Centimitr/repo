const electron = require('electron')
const {app, ipcMain, Notification, Menu} = electron
const util = require('./util')
const ap = require('./aria').get()
ap.init()

let beforeQuit = false
const m = require('./main')(() => beforeQuit)
const n = require('./new')(() => beforeQuit)

// clipboard
let nt
const c = require('./clipboard')
c.watch((text) => {
  if (nt && nt.close) {
    nt.close()
  }
  const uri = util.extractURI(text)
  if (uri) {
    nt = new Notification({
      title: 'Link Found',
      body:  text,
    })
    nt.show()
  }
}, 1000)

app.on('ready', () => {
  m.create()
  n.create(m.w)
  ipcMain.on('kitsune', (event, method) => {
    if (method === 'openDownloadPanel') {
      n.w.show()
    }
  })
})
app.on('before-quit', () => {
  beforeQuit = true
})
app.on('will-quit', c.stopWatch)
app.on('window-all-closed', function () {
  if (process.platform !== 'darwin') {
    app.quit()
  }
})
app.on('activate', function () {
  if (!m.w) {
    m.create()
  } else {
    m.w.show()
  }
})

app.makeSingleInstance(function (argv, workingDirectory) {
  console.log(argv, workingDirectory)
})
