const {BrowserWindow} = require('electron')
const PATH = require('./path').NEW_PATH
const options = {
  modal:     true,
  resizable: false,
  show:      false,
  width:     480,
  height:    375,
}

class NewDownloadWindow {
  constructor (isBeforeQuitFn) {
    this.isBeforeQuitFn = isBeforeQuitFn
  }

  create (parent) {
    const w = new BrowserWindow(Object.assign(options, {parent}))
    w.loadURL(PATH)
    w.on('closed', () => !this.isBeforeQuitFn() && this.create(parent))
    this.w = w
  }
}

module.exports = function () {
  return new NewDownloadWindow(...arguments)
}