const opts = {
  log:               '/Users/shixiao/Desktop/log.txt',
  noConf:            true,
  enableRpc:         true,
  rpcAllowOriginAll: true,
  // rpcSecret: 'hhh',
  // daemon: true
}

function objToMap (obj, renamer) {
  const m = new Map()
  for (let prop in obj) {
    if (obj.hasOwnProperty(prop)) {
      const n = renamer ? renamer(prop) : prop
      m.set(n, obj[prop])
    }
  }
  return m
}

function camelToHyphen (camel) {
  return camel.replace(/([A-Z])/g, '-$1').toLowerCase()
}

function mapToArgs (m) {
  return Array.from(m).map(kv => `--${kv[0]}=${kv[1]}`)
}

const options = mapToArgs(objToMap(opts, camelToHyphen))
module.exports = options
