const {URL} = require('url')

function extractURI (str) {
  try {
    const u = new URL(str)
    return u.toString()
  } catch (e) {
    return null
  }
}

module.exports = {
  extractURI,
}