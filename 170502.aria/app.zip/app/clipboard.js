const {clipboard} = require('electron')

class Clipboard {

  watch (fn, interval) {
    this.stopWatch()
    this.timer = setInterval(() => {
      const text = clipboard.readText()
      if (this.previous !== text) {
        this.previous = text
        fn(text)
      }
    }, interval)
  }

  stopWatch () {
    clearInterval(this.timer)
  }
}

module.exports = new Clipboard()
